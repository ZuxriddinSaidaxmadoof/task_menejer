export class CompanyEntity {
  constructor(dto) {
    this.name = dto.name;
  }
}
