export const roles = {
  SUPERADMIN: "superAdmin",
  ADMIN: "admin",
  MANAGER: "manager",
  WORKER: "worker",
};

export const status = {
  TOOK: "took",
  DONE: "done",
  PROCESS: "process",
};
